
<script>
toastr.options = {
  "closeButton": true,
  "debug": false,
  "newestOnTop": false,
  "progressBar": true,
  "positionClass": "toast-bottom-right",
  "preventDuplicates": false,
  "onclick": null,
  "showDuration": "300",
  "hideDuration": "1000",
  "timeOut": "5000",
  "extendedTimeOut": "1000",
  "showEasing": "swing",
  "hideEasing": "linear",
  "showMethod": "fadeIn",
  "hideMethod": "fadeOut"
}
</script>
<?php if(session('status')): ?>
<?php if(@$message): ?><script>
        toastr.success("<?php echo e(session('status')); ?>")
</script>
<?php endif; ?> <?php endif; ?>
<?php if($message = Session::get('success')): ?>
<?php if(@$message): ?><script>
    toastr.success("<?php echo e($message); ?>")
</script>
<?php endif; ?> <?php endif; ?>
<?php if($message = Session::get('error')): ?>
<?php if(@$message): ?><script>
    toastr.error("<?php echo e($message); ?>")
</script>
<?php endif; ?> <?php endif; ?>
<?php if(Session::has('errors')): ?>
<?php if(@$message): ?><script>
    toastr.error("<?php echo e($message); ?>")
</script>
<?php endif; ?> <?php endif; ?>
<?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/alerts/alert.blade.php ENDPATH**/ ?>