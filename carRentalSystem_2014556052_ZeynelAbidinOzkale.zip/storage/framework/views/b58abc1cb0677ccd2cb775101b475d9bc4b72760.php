<?php $__env->startSection('content'); ?>
      <section class="mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mt-5">
                    <img src="<?php echo e(asset('/assets/brand/logo.svg')); ?>" class="translate-logo mb-2" height="100">
                    <h3><?php echo e(env('APP_NAME')); ?> - Our Vehicles</h3>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-5 table-responsive">
                    <table class="table table-striped table-hover table-sm">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>features</th>
                            <th>Category</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php if($vehicle->image): ?> <img src="<?php echo e(asset(Storage::url($vehicle->image))); ?>" width="100"> <br> <?php else: ?> <img src="<?php echo e(asset('/img/noImage/noImage.png')); ?>" width="100" > <br> <?php endif; ?> <?php echo e($vehicle->name); ?></td>
                              <td><?php echo e($vehicle->seats); ?> seats, <?php echo e($vehicle->bags); ?> bags, <?php echo e($vehicle->doors); ?> doors   </td>
                              <td><b>fuel type:</b> <?php echo e(@$vehicle->fueltype->name); ?>, <b>gear type:</b> <?php echo e(@$vehicle->geartype->name); ?>, <b>Vehicle Class:</b> <?php echo e(@$vehicle->vclass->name); ?> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($vehicles->links()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/home/vehicles.blade.php ENDPATH**/ ?>