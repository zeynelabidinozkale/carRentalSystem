<?php $__env->startSection('content'); ?>
        <h2> Users / Edit </h2>
        <hr class="mb-4">
        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3"><?php echo e($user->name); ?></h4>
                <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('user.update',$user)); ?>"  >
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="_method" value="PATCH">
                  <div class="row">
                    <div class="col-md-4 mb-3">
                      <label for="firstName">Name</label>
                      <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">TC/Passport Number</label>
                        <input type="number" class="form-control" name="tcPassportNo" value="<?php echo e($user->tcPassportNo); ?>" maxlength="20" required>
                    </div>
                    <div class="col-md-4 mb-3"></div>
                    <div class="col-md-4 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" placeholder="you@example.com" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="tel">Tel</label>
                        <input type="tel" class="form-control" value="<?php echo e($user->tel); ?>" name="tel" maxlength="20">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="address">Address</label>
                        <textarea class="form-control" name="address" value="<?php echo e($user->address); ?>" rows="2"><?php echo e($user->address); ?></textarea>
                    </div>
                  </div>
                  <?php if(auth()->user()->hasRole('admin')): ?>
                  <hr class="mb-4">
                    <h4 class="mb-3">Offices</h4>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="offices">Offices</label>
                            <select class="select2 form-control" name="offices[]" multiple>
                                <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($office->id); ?>" <?php if($user->offices->contains($office)): ?> selected <?php endif; ?> > <?php echo e($office->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if($user->is(auth()->user())): ?>
                    <hr class="mb-4">
                    <h4 class="mb-3">Password</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-light" data-toggle="modal" data-target="#changePassword">
                                <span data-feather="key"></span> Change Password
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasRole('admin')): ?>
                    <hr class="mb-4">
                    <h4 class="mb-3">Role</h4>
                    <div class="d-block my-3">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="custom-control custom-radio d-inline mr-2">
                            <input id="<?php echo e($role->name); ?>" name="role_id" type="radio" value="<?php echo e($role->id); ?>" class="custom-control-input" <?php if(@$user->role->name == $role->name): ?> checked <?php endif; ?> required>
                            <label class="custom-control-label" for="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <hr class="mb-4">
                  <button class="btn btn-primary" name="redirect" value="saveAndGoBack" type="submit">Save and Go Back</button>
                  <button class="btn btn-secondary" name="redirect" value="saveAndStayOnThisPage" type="submit">Save and Stay on This Page</button>
                </form>
            </div>
        </div>

        <?php if($user->is(auth()->user())): ?>
            <!-- Modal -->
            <div class="modal fade" id="changePassword" tabindex="-1" role="dialog" aria-labelledby="changePasswordLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('user.update',$user)); ?>" novalidat>
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="_method" value="PATCH">
                            <div class="modal-header">
                            <h5 class="modal-title" id="changePasswordLabel">Change Password</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                                <div class="col-md-12 mb-3">
                                    <label for="currentPassword">Current Password</label>
                                    <input type="password" class="form-control" name="password[currentPassword]" required >
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="email">New Password</label>
                                    <input type="password" class="form-control" name="password[newPassword]" required >
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label for="email">Confirm Password</label>
                                    <input type="password" class="form-control" name="password[confirmNewPassword]" required >
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="passwordChange" value="passwordChange" class="btn btn-primary">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$(function () {
    $('.select2').select2({
        theme: "bootstrap"
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/user/edit.blade.php ENDPATH**/ ?>