<?php $__env->startSection('content'); ?>
        <div class="d-flex justify-space-between">
            <h2>Vehicles</h2>
            <a href="<?php echo e(route('vehicle.create')); ?>" class="btn btn-success align-self-center">+ Create</a>
        </div>
          <div class="table-responsive">
            <table class="table table-striped table-hover table-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>image</th>
                  <th>Name</th>
                  <th>Created At</th>
                  <th>Updated At</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td> <?php if($vehicle->image): ?> <img src="<?php echo e(asset(Storage::url($vehicle->image))); ?>" width="100"> <?php else: ?> <img src="<?php echo e(asset('/img/noImage/noImage.png')); ?>" width="100" > <?php endif; ?></td>
                    <td><?php echo e($vehicle->name); ?></td>
                    <td><?php echo e($vehicle->created_at); ?></td>
                    <td><?php echo e($vehicle->updated_at); ?></td>
                    <td>
                        <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(route('vehicle.edit',$vehicle->id)); ?>">Edit</a>
                        <form autocomplete="off" class="delete d-inline" action="<?php echo e(route('vehicle.destroy',$vehicle->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE"> <?php echo e(csrf_field()); ?> <button class="btn btn-danger btn-sm mr-1 confirmation" type="submit">Delete</button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($vehicles->links()); ?>

          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/vehicle/index.blade.php ENDPATH**/ ?>