<?php $__env->startSection('content'); ?>
        <div >
            <h2>Logs</h2>
        </div>
          <div class="table-responsive">
            <table class="table table-striped table-hover table-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Model Name</th>
                  <th>Model ID</th>
                  <th>Action</th>
                  <th>Created At</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                  <?php
                      $i = 0;
                  ?>
                  <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($log->model); ?></td>
                    <td><?php echo e($log->model_id); ?></td>
                    <td><?php echo e($log->action); ?></td>
                    <td><?php echo e($log->created_at); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/admin/logs.blade.php ENDPATH**/ ?>