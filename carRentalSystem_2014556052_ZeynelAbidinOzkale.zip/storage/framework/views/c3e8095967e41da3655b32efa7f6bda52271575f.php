<?php $__env->startSection('content'); ?>

<br> Hi, Your <?php echo e(env('APP_NAME')); ?> login information is below <br> <br>

<strong>e-mail:</strong> <?php echo e($email); ?> <br>
<strong>Şifre:</strong> <?php echo e($password); ?> <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/mail/register/sendUserRegistered.blade.php ENDPATH**/ ?>