<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/openlayers/4.6.5/ol.css">
<style>
    #map{
        height: 400px;
        border-radius: 4px;
        border:4px solid rgb(17, 141, 17) ;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
      <section class="mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mt-5">
                    <img src="/assets/brand/logo.svg" class="translate-logo mb-2" height="100">
                    <h3><?php echo e(env('APP_NAME')); ?> - Our Offices</h3>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-1">
                    <div id="map" class="map shadow-lg mb-5 mt-4" ></div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-5 table-responsive">
                    <table class="table table-striped table-hover table-sm">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>email</th>
                            <th>Tel</th>
                            <th>Address</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($office->name); ?></td>
                              <td><?php echo e($office->email); ?></td>
                              <td><?php echo e($office->tel); ?></td>
                              <td><?php echo e($office->address); ?></td>
                              <td>
                                    <a class="btn btn-success" href="tel:<?php echo e($office->tel); ?>"> <span data-feather="phone"></span></a>
                                    <a class="btn btn-primary" href="mailto:<?php echo e($office->email); ?>"> <span data-feather="mail"></span></a>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($offices->links()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/openlayers/4.6.5/ol.js"></script>
<script>
    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(is_numeric($office->latitude) && $office->longitude): ?>
    var office_<?php echo e($office->id); ?> = new ol.Feature({
        geometry: new ol.geom.Point(ol.proj.fromLonLat([<?php echo e($office->latitude); ?>,<?php echo e($office->longitude); ?>]))
    });
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    var vectorSource = new ol.source.Vector({
        features: [ <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if(is_numeric($office->latitude) && $office->longitude): ?> office_<?php echo e($office->id); ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ]
    });

var mandalay = ol.proj.fromLonLat([35.4149661,39.1604993]);
var view = new ol.View({
  center: mandalay,
  zoom: 6
});

var vectorSource = new ol.source.Vector({});
var places = [

    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_numeric($office->latitude) && $office->longitude): ?>
        [<?php echo e($office->latitude); ?>,<?php echo e($office->longitude); ?>,'/assets/brand/mapIcon.png'],
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

];

var features = [];
for (var i = 0; i < places.length; i++) {
  var iconFeature = new ol.Feature({
    geometry: new ol.geom.Point(ol.proj.transform([places[i][0], places[i][1]], 'EPSG:4326', 'EPSG:3857')),
  });


  var iconStyle = new ol.style.Style({
    image: new ol.style.Icon({
      src: places[i][2],
      color: places[i][3],
      crossOrigin: 'anonymous',
    })
  });
  iconFeature.setStyle(iconStyle);
  vectorSource.addFeature(iconFeature);
}



var vectorLayer = new ol.layer.Vector({
  source: vectorSource,
  updateWhileAnimating: true,
  updateWhileInteracting: true
});

var map = new ol.Map({
  target: 'map',
  view: view,
  layers: [
    new ol.layer.Tile({
      preload: 3,
      source: new ol.source.OSM(),
    }),
    vectorLayer,
  ],
  loadTilesWhileAnimating: true,
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/home/offices.blade.php ENDPATH**/ ?>