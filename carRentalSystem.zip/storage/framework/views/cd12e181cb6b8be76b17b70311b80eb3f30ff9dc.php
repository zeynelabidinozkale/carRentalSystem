<?php $__env->startSection('content'); ?>
<div style="opacity:0; height:10px;">
    <?php
       print_r($checkoutFormInitialize);
     ?>
  </div>
<div class="mb-4">

</div>
<div id="iyzipay-checkout-form" class="responsive"></div>

<div class="mt-4">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/home/checkout.blade.php ENDPATH**/ ?>