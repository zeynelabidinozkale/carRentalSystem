<?php $__env->startSection('content'); ?>

<section class="mt-5 mb-100">
    <div class="container mb-5">
        <div class="row" >
            <div class="col-md-3">
                <?php echo $__env->make('partial.app.accountSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <h4 class="mb-3"><?php echo e($user->name); ?></h4>
                <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('account.update')); ?>"  >
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-4 mb-3">
                      <label for="firstName">Name</label>
                      <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">TC/Passport Number</label>
                        <input type="number" class="form-control" name="tcPassportNo" value="<?php echo e($user->tcPassportNo); ?>" maxlength="20" required>
                    </div>
                    <div class="col-md-4 mb-3"></div>
                    <div class="col-md-4 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="email">Tel</label>
                        <input type="email" class="form-control" value="<?php echo e($user->tel); ?>" name="tel" maxlength="20">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="address">Address</label>
                        <textarea class="form-control" name="address" value="<?php echo e($user->address); ?>" rows="2"><?php echo e($user->address); ?></textarea>
                    </div>
                  </div>
                    <hr class="mb-4">
                    <h4 class="mb-3">Password</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-light" data-toggle="modal" data-target="#changePassword">
                                <span data-feather="key"></span> Change Password
                            </button>
                        </div>
                    </div>
                    <hr class="mb-4">
                  <button class="btn btn-primary" type="submit">Save Changes</button>
                </form>
            </div>
        </div>

    </div>
</section>

<div class="modal fade" id="changePassword" tabindex="-1" role="dialog" aria-labelledby="changePasswordLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('account.passwordChange')); ?>" novalidat>
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                <h5 class="modal-title" id="changePasswordLabel">Change Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12 mb-3">
                        <label for="currentPassword">Current Password</label>
                        <input type="password" class="form-control" name="password[currentPassword]" required >
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="email">New Password</label>
                        <input type="password" class="form-control" name="password[newPassword]" required >
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="email">Confirm Password</label>
                        <input type="password" class="form-control" name="password[confirmNewPassword]" required >
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" name="passwordChange" value="passwordChange" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/account/index.blade.php ENDPATH**/ ?>