<div class="bg-dark">

    <footer class="container">
        <div class="row pt-5 pb-5">
        <div class="col-12 col-md ">
            <img class="mb-2" src="/assets/brand/logo.svg" alt="" width="100" height="100">
            <small class="d-block mb-3 text-muted">© <?php echo e(date('Y')); ?> <?php echo e(env('APP_NAME')); ?></small>
        </div>
        <div class="col-6 col-md">
            <h5 class="text-light">Pages</h5>
            <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a class="text-muted" href="<?php echo e(route('about')); ?>">About</a></li>
            <li><a class="text-muted" href="<?php echo e(route('vehicles')); ?>">Vehicles</a></li>
            <li><a class="text-muted" href="<?php echo e(route('offices')); ?>">Our Offices</a></li>
            <li><a class="text-muted" href="<?php echo e(route('about')); ?>">Privacy Policy</a></li>
            </ul>
        </div>
        <div class="col-6 col-md">
            <h5 class="text-light">Reservations</h5>
            <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="<?php echo e(route('home.reservation',['step'=>'reservation'])); ?>">Start Reservation</a></li>
            <li><a class="text-muted" href="<?php echo e(route('account.reservations')); ?>">My Reservations</a></li>
            <li><a class="text-muted" href="<?php echo e(route('home.reservation.track')); ?>">Tracking Reservation Records</a></li>
            </ul>
        </div>
        <div class="col-6 col-md">
            <h5 class="text-light">Account</h5>
            <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="<?php echo e(route('account.index')); ?>">My Account</a></li>
            <?php if(Auth::check()): ?>
            <li><a class="text-muted" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
            <?php else: ?>
            <li><a class="text-muted" href="<?php echo e(route('login')); ?>">Login</a></li>
            <li><a class="text-muted" href="<?php echo e(route('register')); ?>">Register</a></li>
            <?php endif; ?>
            </ul>
        </div>
        </div>
    </footer>

</div>
<form autocomplete="off" id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none"> <?php echo csrf_field(); ?> </form>
<?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/partial/app/footer.blade.php ENDPATH**/ ?>