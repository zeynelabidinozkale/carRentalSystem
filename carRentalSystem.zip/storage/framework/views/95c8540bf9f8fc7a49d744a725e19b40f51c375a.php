<?php $__env->startSection('content'); ?>


<section class="mt-5 mb-100">
    <div class="container mb-5">

        <div class="row" >
            <div class="col-md-3">
                <?php echo $__env->make('partial.app.accountSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <div class="card mb-5">
                    <div class="card-header">
                       Invoice
                       <span><strong>Reservation Date: </strong> <?php echo e(\Carbon\Carbon::parse($reservation->created_at)->format('d/m/Y')); ?> - <strong>Time:</strong> <?php echo e(\Carbon\Carbon::parse($reservation->created_at)->format('H:i')); ?></span>
                       <span class="float-right"> <strong>Status:</strong> <?php echo e($reservation->status); ?></span>
                    </div>
                    <div class="card-body">
                       <div class="row mb-4">
                          <div class="col-sm-6">
                             <h6 class="mb-3">From:</h6>
                             <div>
                                <strong>Car Rental System</strong>
                             </div>
                             <div>Lorem Ipsum</div>
                             <div>71-101 Istanbul, Turkey</div>
                             <div>Email: info@carrentalsystem.com.tr</div>
                             <div>Phone: +90 444 666 111</div>
                          </div>
                          <div class="col-sm-6">
                             <h6 class="mb-3">To:</h6>
                             <div>
                                <strong>Client <?php echo e($reservation->billingInformation->name ? $reservation->billingInformation->name: ""); ?> <?php echo e($reservation->billingInformation->companyName ? $reservation->billingInformation->companyName : ""); ?> </strong>
                             </div>
                             <div>Name: <?php echo e($reservation->client->name); ?> </div>
                             <div><?php echo e($reservation->billingInformation->address); ?></div>
                             <div>Email: <?php echo e($reservation->client->email); ?></div>
                             <div>Phone: <?php echo e($reservation->client->tel); ?></div>
                          </div>
                       </div>
                       <div class="table-responsive-sm">
                          <table class="table table-striped">
                             <thead>
                                <tr>
                                   <th class="center">#</th>
                                   <th>Item</th>
                                   <th>Description</th>
                                   <th class="right">Unit Cost</th>
                                   <th class="center">Deposit</th>
                                   <th class="center">Qty (Days) </th>
                                   <th class="right">Total</th>
                                </tr>
                             </thead>
                             <tbody>
                                 <?php
                                     $vehicle = \App\Models\Office::find($reservation->pick_up_office_id)->vehicles()->find($reservation->vehicle_id);
                                 ?>
                                <tr>
                                   <td class="center">1</td>
                                   <td class="left strong"> <?php if($vehicle->image): ?> <img src="<?php echo e(Storage::url($vehicle->image)); ?>" width="100"> <br> <?php endif; ?> <?php echo e($vehicle->name); ?> (<?php echo e($vehicle->vclass->name); ?>)</td>
                                   <td class="left"> <?php echo e($vehicle->seats); ?> seats, <?php echo e($vehicle->bags); ?> bags, <?php echo e($vehicle->doors); ?> doors <br> <b>fuel type:</b> <?php echo e($vehicle->fueltype->name); ?>, <b>gear type:</b> <?php echo e($vehicle->geartype->name); ?>, <b>Vehicle Class:</b> <?php echo e($vehicle->vclass->name); ?> <br>
                                    <b>Pick Up:</b> <?php echo e(\Carbon\Carbon::parse($reservation->reservation_pick_up_datetime)->format('d/m/Y H:i')); ?> - <?php echo e(@$reservation->pickUpOffice->name); ?> <br>
                                    <b>Drop Off:</b> <?php echo e(\Carbon\Carbon::parse($reservation->reservation_drop_off_datetime)->format('d/m/Y H:i')); ?> - <?php echo e(@$reservation->dropOffOffice ? @$reservation->dropOffOffice->name : @$reservation->pickUpOffice->name); ?> <br>
                                    </td>
                                   <td class="right">₺<?php echo e($vehicle->pivot->cost); ?> </td>
                                   <td class="center">₺<?php echo e($vehicle->pivot->deposit); ?></td>
                                   <td class="center"><?php echo e($reservation->days); ?></td>
                                   <td class="right">₺<?php echo e($reservation->total); ?></td>
                                </tr>
                             </tbody>
                          </table>
                       </div>
                       <div class="row">
                          <div class="col-lg-4 col-sm-5">
                          </div>
                          <div class="col-lg-4 col-sm-5 ml-auto">
                             <table class="table table-clear">
                                <tbody>
                                   <tr>
                                      <td class="left">
                                         <strong>Subtotal</strong>
                                      </td>
                                      <td class="right">₺<?php echo e(bcmul($vehicle->pivot->cost, $reservation->days, 2)); ?> </td>
                                   </tr>
                                   <tr>
                                     <td class="left">
                                        <strong>KDV</strong>
                                     </td>
                                     <td class="right">₺<?php echo e(bcmul(bcmul($vehicle->pivot->cost, $reservation->days, 2),'0.18',2)); ?> </td>
                                  </tr>
                                  <tr>
                                     <td class="left">
                                        <strong>Deposit</strong>
                                     </td>
                                     <td class="right">₺<?php echo e($vehicle->pivot->deposit); ?> </td>
                                  </tr>
                                   <tr>
                                      <td class="left">
                                         <strong>Total</strong>
                                      </td>
                                      <td class="right">
                                         <strong> ₺<?php echo e($reservation->toPay); ?> </strong>
                                      </td>
                                   </tr>
                                </tbody>
                             </table>
                          </div>
                       </div>
                    </div>
                 </div>
            </div>
        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/account/reservationDetails.blade.php ENDPATH**/ ?>