<?php $__env->startSection('content'); ?>
        <div class="d-flex justify-space-between">
            <h2>Users</h2>
            <span class="d-flex">
                <a href="<?php echo e(route('user.create',['role'=>$request->role])); ?>" class="btn btn-success align-self-center mr-2">+ Create</a>
                <div class="dropdown align-self-center">
                    <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Filter Role <?php if(isset($request->role)): ?>(<?php echo e($request->role); ?>)<?php endif; ?>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="<?php echo e(route('user.index')); ?>">All</a>
                        <?php $__currentLoopData = \App\Models\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('user.index',['role'=>$role->name])); ?>"><?php echo e($role->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </span>
        </div>
          <div class="table-responsive">
            <table class="table table-striped table-hover table-sm">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Role</th>
                  <th>Tel</th>
                  <th>e-mail</th>
                  <th>Registered</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e(@$user->role->name); ?></td>
                    <td><?php echo e($user->tel); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->created_at); ?></td>
                    <td>
                        <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(route('user.edit',$user->id)); ?>">Edit</a>
                        <a class="btn btn-warning btn-sm mr-1 confirmation" href="<?php echo e(route('sendCredentials',$user->id)); ?>">Send Credentials</a>
                        <form autocomplete="off" class="delete d-inline" action="<?php echo e(route('user.destroy',$user->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE"> <?php echo e(csrf_field()); ?> <button class="btn btn-danger btn-sm mr-1 confirmation" type="submit">Delete</button>
                        </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($users->links()); ?>

          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/user/index.blade.php ENDPATH**/ ?>