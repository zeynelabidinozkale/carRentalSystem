<?php $__env->startSection('content'); ?>
        <div class="d-flex justify-space-between">
            <h2>Reservations</h2>
            <div class="d-inline">
                <form action="" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" value="<?php echo e(old('trackNumber')); ?>" name="trackNumber" placeholder="Tracking Number">
                        <div class="input-group-append">
                            <button class="btn btn-success">Search</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="dropdown align-self-center">
                <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Filter Reservations <?php if(isset($request->mode)): ?>(<?php echo e($request->mode); ?>)<?php endif; ?>
                </button>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="<?php echo e(route('reservation.index')); ?>">All</a>
                    <a class="dropdown-item" href="<?php echo e(route('reservation.index',['mode'=>'newReservations'])); ?>">New Reservations</a>
                    <a class="dropdown-item" href="<?php echo e(route('reservation.index',['mode'=>'futureReservations'])); ?>">Future Reservations</a>
                    <a class="dropdown-item" href="<?php echo e(route('reservation.index',['mode'=>'previousReservations'])); ?>">Previous Reservations</a>
                </div>
            </div>
        </div>

        <div class="col-md-8"></div>
        <div class="table-responsive">
        <table class="table table-striped table-hover table-sm">
            <thead>
                <tr>
                <th>Vehicle</th>
                <th>Pick Up Office</th>
                <th>Drop Off Office</th>
                <th>Reservation Date</th>
                <th>Pick Up Date</th>
                <th>Drop Off Date</th>
                <th>Status</th>
                <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php if($reservation->vehicle->image): ?> <img src="<?php echo e(Storage::url($reservation->vehicle->image)); ?>" width="100"> <br> <?php endif; ?> <?php echo e($reservation->vehicle->name); ?></td>
                    <td><?php echo e(@$reservation->pickUpOffice->name); ?></td>
                    <td><?php echo e(@$reservation->dropOffOffice->name); ?></td>
                    <td><?php echo e($reservation->created_at); ?></td>
                    <td><?php echo e($reservation->reservation_pick_up_datetime); ?></td>
                    <td><?php echo e($reservation->reservation_drop_off_datetime); ?></td>
                    <td>
                        <?php switch($reservation->status):
                            case ('pending'): ?>
                                <span class="badge badge-warning badge-lg"><?php echo e($reservation->status); ?></span>
                                <?php break; ?>
                            <?php case ('paid'): ?>
                                <span class="badge badge-success badge-lg"><?php echo e($reservation->status); ?></span>
                                <?php break; ?>
                            <?php case ('canceled'): ?>
                                <span class="badge badge-danger badge-lg"><?php echo e($reservation->status); ?></span>
                                <?php break; ?>
                            <?php default: ?>
                        <?php endswitch; ?>
                    </td>
                    <td>
                    <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(route('reservation.edit',$reservation->id)); ?>">Edit</a>
                    <form autocomplete="off" class="delete d-inline" action="<?php echo e(route('reservation.destroy',$reservation->id)); ?>" method="POST">
                        <input type="hidden" name="_method" value="DELETE"> <?php echo e(csrf_field()); ?> <button class="btn btn-danger btn-sm mr-1 confirmation" type="submit">Delete</button>
                    </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            <?php echo e($reservations->links()); ?>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/reservation/index.blade.php ENDPATH**/ ?>