<?php $__env->startSection('content'); ?>

<section class="mt-5 mb-100">
    <div class="container mb-5">
        <div class="row" >
            <div class="col-md-3">
                <?php echo $__env->make('partial.app.accountSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-9">
                <?php if(auth()->user()->reservations->count()>0): ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-sm">
                      <thead>
                        <tr>
                          <th>Vehicle</th>
                          <th>Pick Up Office</th>
                          <th>Drop Off Office</th>
                          <th>Reservation Date</th>
                          <th>Pick Up Date</th>
                          <th>Drop Off Date</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = auth()->user()->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td> <?php if($reservation->vehicle->image): ?> <img src="<?php echo e(Storage::url($reservation->vehicle->image)); ?>" width="100"> <br> <?php endif; ?> <?php echo e($reservation->vehicle->name); ?></td>
                            <td><?php echo e(@$reservation->pickUpOffice->name); ?></td>
                            <td><?php echo e(@$reservation->dropOffOffice->name); ?></td>
                            <td><?php echo e($reservation->created_at); ?></td>
                            <td><?php echo e($reservation->reservation_pick_up_datetime); ?></td>
                            <td><?php echo e($reservation->reservation_drop_off_datetime); ?></td>
                            <td>
                                <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(route('account.reservationDetails',['id'=>$reservation->id])); ?>">View Details</a>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                <?php else: ?>
                  <div class="alert alert-warning"> You do not have a reservation yet </div>
                <?php endif; ?>



                
            </div>
        </div>

    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/account/reservations.blade.php ENDPATH**/ ?>