<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <div class="col-md-12">
        <div class="row">
            <?php if(auth()->user()->hasRole('admin')): ?>
            <div class="col-md-3 col-sm-6">
                <div class="card text-white bg-primary mb-3 hover-pointer" onclick="location.href='<?php echo e(route('vehicle.index')); ?>'" >
                    <div class="card-body">
                      <h5 class="card-title">VEHICLES (<?php echo e(\App\Models\Vehicle::count()); ?>)</h5>
                      <p class="card-text">Click here to go to manage vehicles page.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-white bg-success mb-3 hover-pointer" onclick="location.href='<?php echo e(route('office.index')); ?>'" >
                    <div class="card-body">
                      <h5 class="card-title">ALL OFFICES (<?php echo e(\App\Models\Office::count()); ?>)</h5>
                      <p class="card-text">Click here to go to manage offices page.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-white bg-danger mb-3 hover-pointer" onclick="location.href='<?php echo e(route('user.index',['role'=>'client'])); ?>'" >
                    <div class="card-body">
                      <h5 class="card-title">CLIENTS (<?php echo e(\App\Models\User::whereHas('role',function($u){ $u->where('name','client'); })->count()); ?>)</h5>
                      <p class="card-text">Click here to go to manage clients page.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card text-white bg-dark mb-3 hover-pointer" onclick="location.href='<?php echo e(route('reservation.index')); ?>'" >
                    <div class="card-body">
                      <h5 class="card-title">Reservations (<?php echo e(\App\Models\Reservation::count()); ?>)</h5>
                      <p class="card-text">Click here to go to manage reservations page.</p>
                    </div>
                </div>
            </div>
            <?php else: ?>

            <?php
                $user = auth()->user();

                $offices = auth()->user()->offices;
                $reservations = \App\Models\Reservation::whereIn('pick_up_office_id',$offices->pluck('id'));

            ?>
                <div class="col-md-6">
                    <div class="card text-white bg-success mb-3 hover-pointer" onclick="location.href='<?php echo e(route('office.index')); ?>'" >
                        <div class="card-body">
                          <h5 class="card-title">OFFICES (<?php echo e($offices->count()); ?>)</h5>
                          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card text-white bg-dark mb-3 hover-pointer" onclick="location.href='<?php echo e(route('reservation.index')); ?>'" >
                        <div class="card-body">
                          <h5 class="card-title">Reservations (<?php echo e($reservations->count()); ?>)</h5>
                          <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-md-12 table-resonsive">
                <?php if($reservations->count()>0): ?>
                <div class="alert alert-warning">There are <b><?php echo e($reservations->count()); ?></b> new reservations</div>
                    <table class="table table-striped table-hover table-sm table-resonsive">
                        <thead>
                            <tr>
                            <th>Vehicle</th>
                            <th>Pick Up Office</th>
                            <th>Drop Off Office</th>
                            <th>Reservation Date</th>
                            <th>Pick Up Date</th>
                            <th>Drop Off Date</th>
                            <th>Status</th>
                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php if($reservation->vehicle->image): ?> <img src="<?php echo e(Storage::url($reservation->vehicle->image)); ?>" width="100"> <br> <?php endif; ?> <?php echo e($reservation->vehicle->name); ?></td>
                                <td><?php echo e(@$reservation->pickUpOffice->name); ?></td>
                                <td><?php echo e(@$reservation->dropOffOffice->name); ?></td>
                                <td><?php echo e($reservation->created_at); ?></td>
                                <td><?php echo e($reservation->reservation_pick_up_datetime); ?></td>
                                <td><?php echo e($reservation->reservation_drop_off_datetime); ?></td>
                                <td>
                                    <?php switch($reservation->status):
                                        case ('pending'): ?>
                                            <span class="badge badge-warning badge-lg"><?php echo e($reservation->status); ?></span>
                                            <?php break; ?>
                                        <?php case ('paid'): ?>
                                            <span class="badge badge-success badge-lg"><?php echo e($reservation->status); ?></span>
                                            <?php break; ?>
                                        <?php case ('canceled'): ?>
                                            <span class="badge badge-danger badge-lg"><?php echo e($reservation->status); ?></span>
                                            <?php break; ?>
                                        <?php default: ?>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                <a class="btn btn-primary btn-sm mr-1" href="<?php echo e(route('reservation.edit',$reservation->id)); ?>">Edit</a>
                                <form autocomplete="off" class="delete d-inline" action="<?php echo e(route('reservation.destroy',$reservation->id)); ?>" method="POST">
                                    <input type="hidden" name="_method" value="DELETE"> <?php echo e(csrf_field()); ?> <button class="btn btn-danger btn-sm mr-1 confirmation" type="submit">Delete</button>
                                </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-warning">There are no new reservations</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>