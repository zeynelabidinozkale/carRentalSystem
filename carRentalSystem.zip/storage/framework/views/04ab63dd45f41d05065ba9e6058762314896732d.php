<?php $__env->startSection('content'); ?>
        <h2> Vehicle / Edit </h2>
        <hr class="mb-4">
        <div class="row">
            <div class="col-md-8">
                <h4 class="mb-3"><?php echo e($vehicle->name); ?></h4>
                <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('vehicle.update',$vehicle)); ?>"  enctype="multipart/form-data"  >
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="_method" value="PATCH">
                  <div class="row">

                    <?php if($vehicle->image): ?>
                    <div class="col-md-12 mb-3">
                        <img src="<?php echo e(Storage::url($vehicle->image)); ?>" width="240">
                    </div>
                    <?php endif; ?>
                    <div class="col-md-6 mb-3">
                      <label for="firstName">Name</label>
                      <input type="text" class="form-control" name="name" value="<?php echo e($vehicle->name); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="firstName">İmage</label>
                        <?php if($vehicle->image): ?>
                            <input type="hidden" name="imageUrl" value="<?php echo e($vehicle->image); ?>">
                        <?php endif; ?>
                        <input type="file" class="form-control" name="image" >
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Seats</label>
                        <input type="number" class="form-control"  name="seats" value="<?php echo e($vehicle->seats); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Bags</label>
                        <input type="number" class="form-control" name="bags" value="<?php echo e($vehicle->bags); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Doors</label>
                        <input type="number" class="form-control" name="doors" value="<?php echo e($vehicle->doors); ?>" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Vehicle Class</label>
                        <select class="form-control" name="vclass_id" required>
                            <option value="">---</option>
                            <?php $__currentLoopData = $vclasses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($vclass->id); ?>" <?php if($vclass->id == $vehicle->vclass_id): ?> selected <?php endif; ?> ><?php echo e($vclass->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Fuel Type</label>
                        <select class="form-control" name="fueltype_id" required>
                            <option value="">---</option>
                            <?php $__currentLoopData = $fueltypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fueltype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fueltype->id); ?>" <?php if($fueltype->id == $vehicle->fueltype_id): ?> selected <?php endif; ?> ><?php echo e($fueltype->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">Gear Type</label>
                        <select class="form-control" name="geartype_id" required>
                            <option value="">---</option>
                            <?php $__currentLoopData = $geartypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geartype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($geartype->id); ?>" <?php if($geartype->id == $vehicle->geartype_id): ?> selected <?php endif; ?> ><?php echo e($geartype->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <div class="col-md-12 mb-3">
                        <label for="firstName">Notes</label>
                        <textarea name="notes" rows="2" class="form-control" value="<?php echo e($vehicle->notes); ?>" ><?php echo e($vehicle->notes); ?></textarea>
                    </div>
                  </div>
                    <hr class="mb-4">
                  <button class="btn btn-primary" type="submit">Save Changes</button>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/vehicle/edit.blade.php ENDPATH**/ ?>