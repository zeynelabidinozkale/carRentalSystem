<?php $__env->startSection('content'); ?>
        <h2> Users / Create </h2>
        <hr class="mb-4">
        <div class="row">
            <div class="col-md-8">
                <form autocomplete="off" class="needs-validation" method="POST" action="<?php echo e(route('user.store')); ?>" >
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-md-4 mb-3">
                      <label for="firstName">Name</label>
                      <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="firstName">TC/Passport Number</label>
                        <input type="number" class="form-control" name="tcPassportNo" maxlength="20" required>
                    </div>
                    <div class="col-md-4 mb-3"></div>
                    <div class="col-md-4 mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="tel">Tel</label>
                        <input type="tel" class="form-control" name="tel" maxlength="20">
                    </div>
                    <div class="col-md-12 mb-3">
                        <label for="address">Address</label>
                        <textarea class="form-control" name="address" rows="2"></textarea>
                    </div>
                  </div>
                    <hr class="mb-4">
                    <h4 class="mb-3">Office</h4>
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="offices">Offices</label>
                            <select class="select2 form-control" name="offices[]" multiple>
                                <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($office->id); ?>"> <?php echo e($office->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <hr class="mb-4">
                    <h4 class="mb-3">Role</h4>
                    <div class="d-block my-3">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!auth()->user()->hasRole('admin')): ?>
                        <?php if($role->name!='admin'): ?>
                        <div class="custom-control custom-radio d-inline mr-2">
                            <input id="<?php echo e($role->name); ?>" name="role_id" type="radio" value="<?php echo e($role->id); ?>" class="custom-control-input" <?php if($role->name == $request->role): ?> checked <?php endif; ?> required>
                            <label class="custom-control-label" for="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></label>
                        </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <div class="custom-control custom-radio d-inline mr-2">
                            <input id="<?php echo e($role->name); ?>" name="role_id" type="radio" value="<?php echo e($role->id); ?>" class="custom-control-input" <?php if($role->name == $request->role): ?> checked <?php endif; ?> required>
                            <label class="custom-control-label" for="<?php echo e($role->name); ?>"><?php echo e($role->name); ?></label>
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr class="mb-4">
                  <button class="btn btn-primary" type="submit">Save Changes</button>
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(function () {
    $('.select2').select2({
        theme: "bootstrap"
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/user/create.blade.php ENDPATH**/ ?>