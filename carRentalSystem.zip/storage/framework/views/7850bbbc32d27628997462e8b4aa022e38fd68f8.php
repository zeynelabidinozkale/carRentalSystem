<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top" id="nav">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand mr-1" href="<?php echo e(route('home')); ?>"> <img src="/assets/brand/logo.svg" class="translate-logo" height="32"> <?php echo e(config('app.name', 'Laravel')); ?> </a>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav mr-auto mt-2 ml-5 mt-lg-0">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('home')); ?>" > <span data-feather="home"></span> Home </a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('about')); ?>" > <span data-feather="award"></span> About </a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('vehicles')); ?>" > <i class="fa fa-car-side fa-xl"></i> Vehicles </a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('offices')); ?>" > <span data-feather="map-pin"></span> Our Offices </a>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role->panelLogin): ?>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>" > <span data-feather="sidebar"></span> Dashboard </a>
        </li>
        <?php else: ?>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('account.index')); ?>" > <span data-feather="user"></span> My Account </a>
        </li>
        <?php endif; ?>
        <?php else: ?>
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('account.index')); ?>" > <span data-feather="user"></span> My Account </a>
        </li>
        <?php endif; ?>
      </ul>
      <ul class="m-0 list-style-none maker-none" >
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item dropdown ">
                <div class="btn-group">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        My account
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <?php if(Route::has('login')): ?> <button class="dropdown-item hover-pointer" type="button" onclick="window.location.href = '<?php echo e(route('login')); ?>'">login</button><?php endif; ?>
                        <?php if(Route::has('register')): ?><button class="dropdown-item hover-pointer" type="button" onclick="window.location.href = '<?php echo e(route('register')); ?>'">Register</button><?php endif; ?>
                    </div>
                </div>
            </li>
            <?php else: ?>
            <li class="nav-item dropdown maker-none">
                <div class="btn-group">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <button class="dropdown-item hover-pointer" type="button" onclick="location.href = '<?php if(auth()->user()->role->panelLogin): ?> <?php echo e(route('user.edit',auth()->user())); ?> <?php else: ?> <?php echo e(route('account.index')); ?> <?php endif; ?>'">My account</button>
                        <?php if(auth()->user()->role->panelLogin): ?> <button class="dropdown-item hover-pointer" type="button"  onclick="location.href = '<?php echo e(route('dashboard')); ?>'">Dashboard</button> <?php else: ?> <button class="dropdown-item hover-pointer" type="button"  onclick="location.href = '<?php echo e(route('account.reservations')); ?>'">Reservations</button> <?php endif; ?>
                        <button class="dropdown-item hover-pointer" type="button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></button>
                    </div>
                </div>
                <form autocomplete="off" id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        <?php endif; ?>
    </ul>
    </div>
  </nav>
<?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/partial/app/header.blade.php ENDPATH**/ ?>