<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>"> <img src="/assets/brand/logo.svg" class="translate-logo" height="32"> <?php echo e(config('app.name', 'Laravel')); ?> </a>

    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
    <ul class="navbar-nav mr-auto mt-2 ml-5 mt-lg-0 menu-md ">
        <li class="nav-item active">
            <a class="nav-link" href="<?php echo e(route('home')); ?>" target="_blank"> <span data-feather="corner-up-left"></span> Go To Site <span class="sr-only">(current)</span></a>
        </li>
    </ul>
      <ul class="navbar-nav mr-auto mt-2 ml-5 mt-lg-0 menu-sm">
        <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <span data-feather="home"></span>
                Dashboard
              </a>
            </li>
            <?php if(auth()->user()->hasRole('admin')): ?>
            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                <span>User Management</span>
                <a class="d-flex align-items-center text-muted" href="#">
                  <span data-feather="plus-circle"></span>
                </a>
            </h6>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
                  <span data-feather="users"></span>
                  All Users
                </a>
            </li>
            <?php $__currentLoopData = \App\Models\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.index',['role'=>$role->name])); ?>">
                  <span data-feather="users"></span>
                  <?php echo e(ucfirst($role->name)); ?>s
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                <span>Vehicle Fleet</span>
                <a class="d-flex align-items-center text-muted" href="#">
                  <span data-feather="plus-circle"></span>
                </a>
            </h6>

            <ul class="nav flex-column mb-2">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('vehicle.index')); ?>">
                        <span data-feather="server"></span>
                        Vehicles
                    </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('fueltype.index')); ?>">
                    <span data-feather="server"></span>
                    Fuel Types
                  </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('geartype.index')); ?>">
                      <span data-feather="server"></span>
                      Gear Types
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('vclass.index')); ?>">
                        <span data-feather="server"></span>
                        Vehicle Classes
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('office.index')); ?>">
                        <span data-feather="server"></span>
                        Offices
                    </a>
                </li>
              </ul>
              <?php else: ?>
              <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                <span>Reservations</span>
                <a class="d-flex align-items-center text-muted" href="#">
                  <span data-feather="plus-circle"></span>
                </a>
            </h6>
                <ul class="nav flex-column mb-2">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('office.index')); ?>">
                            <span data-feather="server"></span>
                            Offices
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('reservation.index')); ?>">
                            <span data-feather="server"></span>
                            Reservations
                        </a>
                    </li>
                </ul>
              <?php endif; ?>
            
          </ul>
          <?php if(auth()->user()->hasRole('admin')): ?>
          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>System</span>
            <a class="d-flex align-items-center text-muted" href="#">
              <span data-feather="plus-circle"></span>
            </a>
          </h6>
          <ul class="nav flex-column mb-2">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('logs')); ?>">
                <span data-feather="server"></span>
                Logs
              </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('role.index')); ?>">
                  <span data-feather="tool"></span>
                  Roles
                </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('user.edit',['user'=>auth()->user()])); ?>">
                <span data-feather="settings"></span>
                Account
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span data-feather="file-text"></span>
                Logout
              </a>
            </li>
          </ul>
          <?php else: ?>
          <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
            <span>Account</span>
            <a class="d-flex align-items-center text-muted" href="#">
              <span data-feather="plus-circle"></span>
            </a>
          </h6>
          <ul class="nav flex-column mb-2">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('user.edit',['user'=>auth()->user()])); ?>">
                <span data-feather="settings"></span>
                Account
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span data-feather="file-text"></span>
                Logout
              </a>
            </li>
          </ul>
          <?php endif; ?>
      </ul>
      <ul class="m-0 pl-0 list-style-none" >
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item dropdown maker-none">
                <div class="btn-group">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Auth
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <?php if(Route::has('login')): ?> <button class="dropdown-item hover-pointer" type="button" onclick="window.location.href = '<?php echo e(route('login')); ?>'">login</button><?php endif; ?>
                        <?php if(Route::has('register')): ?><button class="dropdown-item hover-pointer" type="button" onclick="window.location.href = '<?php echo e(route('register')); ?>'">Register</button><?php endif; ?>
                    </div>
                </div>
            </li>
            <?php else: ?>
            <li class="nav-item dropdown maker-none">
                <div class="btn-group">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </button>
                    <div class="dropdown-menu dropdown-menu-right">
                        <button class="dropdown-item hover-pointer" type="button" onclick="window.location.href = '<?php echo e(route('user.edit',['user'=>auth()->user()])); ?>'">Account</button>
                        <button class="dropdown-item hover-pointer" type="button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></button>
                    </div>
                </div>
                <form autocomplete="off" id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        <?php endif; ?>
    </ul>
    </div>
  </nav>
<?php /**PATH C:\Users\Lenovo\Projeler\carRentalSystem\resources\views/partial/admin/header.blade.php ENDPATH**/ ?>